To force sphinx to rebuild the html files run `python -m sphinx-build -M html . ./_build -a` in the cmd when you're in the docs folder.

Make sure you also run the following in your environment:

`pip install sphinxcontrib-bibtex`
`pip install sphinx_autodoc_typehints`
`pip install sphinx-rtd-theme`
`pip install sphinx`