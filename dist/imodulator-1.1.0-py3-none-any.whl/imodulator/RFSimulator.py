from __future__ import annotations

from matplotlib import pyplot as plt
from matplotlib.gridspec import GridSpec

from shapely.geometry import (
    Polygon,
    LineString,
    MultiLineString,
    LinearRing,
)
from shapely.ops import clip_by_rect, linemerge

from skfem.io.meshio import from_meshio
from skfem.visuals.matplotlib import draw_mesh2d
from skfem import Basis, ElementTriP0, ElementTriP1, ElementVector, ElementDG, Functional
from skfem.helpers import inner
from skfem import adaptive_theta

# femwell is an optional dependency (pip install imodulator[femwell]). Import it
# here without failing so `import imodulator` works when it is absent;
# RFSimulatorFEMWELL raises a clear error at instantiation if it is missing.
try:
    from femwell.mesh import mesh_from_OrderedDict
    from femwell.maxwell.waveguide import Modes, Mode, calculate_scalar_product, compute_modes
except ModuleNotFoundError:
    pass

import numpy as np
import copy
from pint import Quantity

from imodulator import PhotonicDevice
from imodulator._optional_deps import require
from collections import OrderedDict
import warnings

from imodulator.PhotonicPolygon import (
    SemiconductorPolygon,
    MetalPolygon,
    InsulatorPolygon,
)

PhotonicPolygon = SemiconductorPolygon | MetalPolygon | InsulatorPolygon
Line = LineString | MultiLineString | LinearRing


class RFSimulatorFEMWELL:
    """
    Base class for RF simulation of a PhotonicDevice. The role of the RFsimulator is to:

    .. warning::
        The algorithm to search for junctions is not active at the moment. It is a feature that will be implemented in the future.

    * generate the RF mesh;
    * apply RF simmetry planes;
    * Generate field visualizations of the RF modes;
    * Generate mesh visuals;
    * Solve for the RF modes;
    * Return small-signal S parameters;
    * Return RLGC parameters based on waveguide theory;

    """

    def __init__(
        self,
        device: PhotonicDevice,
        simulation_window: Polygon | None = None,
    ):
        """
        Initializes the simulator with the photonic device and the simulation window.

        Args:
            device: The :class:`PhotonicDevice` object to simulate.
            simulation_window: The simulation window to use for the RF simulation. If None, the entire device is simulated.

        .. note::
            The simulation window MUST be a rectangle. If not, the simulation will fail. Also beware that the definition of the simulation window is how you can make use of symmetry planes through the definition of metal boundaries or not. See `compute_modes` for more information on how to use the symmetry planes.

        """
        require("femwell", "femwell")

        self.photodevice = device
        self.reg = self.photodevice.reg

        self.e = 1.602176634e-19 * self.reg.coulomb
        self.e0 = 8.854e-12 * self.reg.farad * self.reg.meter**-1
        self.c = 3e8 * self.reg.meter * self.reg.second**-1  # m s^-1
        self.mu0 = (
            4 * np.pi * 1e-7 * self.reg.henry / self.reg.meter
        )  # vacuum magnetic permeability

        self.simulation_window = simulation_window

        self.rf_photopolygons = copy.deepcopy(self.photodevice.photo_polygons)
        self.line_entities = copy.deepcopy(self.photodevice.line_entities)
        self.polygon_entities = OrderedDict()
        self.junction_entities = OrderedDict()
        self.resolutions = dict()

        # # Add the lines for line integrals of currents
        # for polygon in self.rf_photopolygons:

        #     if polygon.calculate_current:

        #         line = LineString(
        #             polygon.polygon.buffer(
        #                 polygon.d_buffer_current, join_style="bevel"
        #             ).exterior
        #         )
        #         self.line_entities[polygon.name + "line_current"] = line

        # THIS NEEDS A REFACTOR!!!
        if simulation_window is None:
            # Select all junctions cutted by the simulation window
            for name, poly in self.photodevice.junction_entities.items():
                self.junction_entities[name] = poly

        elif simulation_window is not None:
            if not np.isclose(
                simulation_window.minimum_rotated_rectangle.area, simulation_window.area
            ):
                raise ValueError("simulation window must be a rectangle")

            # Cut all photopolygons by the simulation window
            idxs_to_pop = []
            for i, poly in enumerate(self.rf_photopolygons):
                if poly.polygon.intersects(simulation_window) and not simulation_window.contains(
                    poly.polygon
                ):
                    poly_tmp = clip_by_rect(poly.polygon, *simulation_window.bounds)

                    if poly_tmp.is_empty:
                        idxs_to_pop.append(i)
                    else:
                        self.rf_photopolygons[i].polygon = poly_tmp

                elif not poly.polygon.intersects(simulation_window):
                    idxs_to_pop.append(i)

            for index in sorted(idxs_to_pop, reverse=True):
                del self.rf_photopolygons[index]

            # Cut all the line entities by the simulation window
            keys_to_pop = []
            for key, poly in self.line_entities.items():
                if poly.intersects(simulation_window) and not simulation_window.contains(poly):
                    poly_tmp = clip_by_rect(poly, *simulation_window.bounds)

                    if type(poly_tmp) == MultiLineString:
                        self.line_entities[key] = linemerge(poly_tmp)

                    elif poly_tmp.is_empty:
                        keys_to_pop.append(key)
                    else:
                        self.line_entities[key] = poly_tmp
                elif not poly.intersects(simulation_window):
                    keys_to_pop.append(key)

            for key in keys_to_pop:
                self.line_entities.pop(key)

            # Select all junctions cutted by the simulation window
            for name, poly in self.photodevice.junction_entities.items():
                if poly.intersects(simulation_window) and not simulation_window.contains(poly):
                    poly_tmp = clip_by_rect(polygon, *simulation_window.bounds)

                    if not poly_tmp.is_empty:
                        self.junction_entities[name] = poly_tmp

                elif simulation_window.contains(poly):
                    self.junction_entities[name] = poly

        for polygon in self.rf_photopolygons:
            self.polygon_entities[polygon.name] = polygon.polygon
        # We now have all the photopolygons cut by the plane. Let us finally add the boundaries

        surf_bounds = self.polygon_entities["background"].bounds

        left = LineString([(surf_bounds[0], surf_bounds[1]), (surf_bounds[0], surf_bounds[3])])

        bottom = LineString([(surf_bounds[0], surf_bounds[1]), (surf_bounds[2], surf_bounds[1])])

        right = LineString([(surf_bounds[2], surf_bounds[1]), (surf_bounds[2], surf_bounds[3])])

        top = LineString([(surf_bounds[0], surf_bounds[3]), (surf_bounds[2], surf_bounds[3])])

        self.line_entities["left"] = left
        self.line_entities["bottom"] = bottom
        self.line_entities["right"] = right
        self.line_entities["top"] = top

        # We now need to check if any polygon is fully covered by a higher priority polygon. If so, we remove it from the simulation
        polygons_to_remove = []
        for i, (poly_name, poly_to_check) in enumerate(
            reversed(self.polygon_entities.items())
        ):  # We loop from lowest priority to highest
            difference_poly = None
            for poly_higher_name, poly_higher in list(
                reversed(self.polygon_entities.items())
            )[
                i + 1 :
            ]:  # We loop through all the higher priority polygons and keep removing their area from the poly_to_check
                difference_poly = (
                    poly_to_check.difference(poly_higher)
                    if difference_poly is None
                    else difference_poly.difference(poly_higher)
                )

                if difference_poly.is_empty:
                    polygons_to_remove.append(poly_name)
                    print(
                        f'The polygon "{poly_name}" is fully covered by a higher priority polygons. It will be removed from the simulation.'
                    )
                    break

        # Remove the polygons that are fully covered by higher priority polygons
        for poly_name in polygons_to_remove:
            self.polygon_entities.pop(poly_name)

            # Also remove it from the rf_photopolygons list
            for i, poly in enumerate(self.rf_photopolygons):
                if poly.name == poly_name:
                    self.rf_photopolygons.pop(i)
                    break

        self.entities = OrderedDict(
            list(self.line_entities.items())
            + list(self.junction_entities.items())
            + list(self.polygon_entities.items())
        )

        # Transfer the resolutions from the photonic device to the rf_simulator
        for name in self.entities.keys():
            if name in self.photodevice.resolutions_rf.keys():
                self.resolutions[name] = self.photodevice.resolutions_rf[name]

    def make_mesh(
        self,
        default_resolution_min: float = 1e-12,
        default_resolution_max: float = 100,
        filename: str = None,
        gmsh_algorithm: int = 5,
        global_quad: bool = False,
        verbose: bool = False,
        mesh_scaling_factor: float = 1.0,
    ):
        """
        Returns a `gmsh <https://gmsh.info/>`_ with the geometric information of the photonic device. The mesh generation is currently handled by `FEMWELL`_, but it will later be deprecated in favour of `MESHWELL`_.

        Args:
            default_resolution_min: The minimum resolution to use for the mesh generation if no resolution is specified for a given entity.
            default_resolution_max: The maximum resolution to use for the mesh generation if no resolution is specified for a given entity.
            filename: The filename to save the mesh to. If `None`, the mesh is not saved.
            gmsh_algorithm: The algorithm to use for the mesh generation.
            global_quad: Whether to use global quadrature for the mesh generation.
            verbose: Whether to print verbose output during the mesh generation.
            mesh_scaling_factor: The scaling factor to apply to the mesh.

        """
        self.mesh = from_meshio(
            mesh_from_OrderedDict(
                self.entities,
                self.resolutions,
                default_resolution_max=default_resolution_max,
                default_resolution_min=default_resolution_min,
                filename=filename,
                gmsh_algorithm=gmsh_algorithm,
                global_quad=global_quad,
                verbose=verbose,
                mesh_scaling_factor=mesh_scaling_factor,
            )
        )
        # Choosing ElementTriP0 is crucial as it assumes one dof per element. A nodal
        # (P1) basis cannot represent the permittivity jump at a material interface:
        # a node shared by two polygons can only hold one value, so whichever polygon
        # is written last wins and its permittivity bleeds one element deep into its
        # neighbour. That silently strips the conductivity from thin doped layers.
        self.basis = Basis(self.mesh, ElementTriP0())

    def refine_mesh(
        self,
        N_nearest_neighbours: int = 200,
        mode_for_refinement: Mode = None,
    ):
        """
        Refines the mesh based on the computed RF modes.

        Args:
            N_nearest_neighbours: Number of nearest neighbors when finding the facets in the new mesh corresponding to the old mesh boundaries. If you have a very fine mesh, it is wise to make this number higher. If it's not high enough, it may not update the named boundaries in its entirety, and you end up with wrong line integrals. Of course, the higher it is, the slower the algorithm.
            mode_for_refinement: the mode to be used for refinement.

        Returns:
            None

        """

        old_mesh = self.mesh

        elements_to_refine = adaptive_theta(mode_for_refinement.eval_error_estimator(), theta=0.5)

        new_mesh = old_mesh.refined(elements_to_refine)

        new_boundaries = get_named_boundaries_in_refined_mesh(
            old_mesh, new_mesh, N=N_nearest_neighbours
        )

        self.mesh = new_mesh
        self.mesh._boundaries = new_boundaries
        self.basis = Basis(self.mesh, ElementTriP0())

    def get_epsilon_rf(
        self, frequency: float, use_charge_transport_data: bool = False, voltage_idx: int = 0
    ):
        """
        This function will return the :math:`\epsilon_{RF}` tensor with the signature ``self.epsilon_rf[element_idx, voltage_idx]`` where ``element_idx`` is the index of the element in the mesh and `voltage_idx` is the index of the voltage in the bias points. In case no bias dependent data is available (i.e. no charge transport data is available) the ``voltage_idx`` must be 0 as the second axis of the array will have size 1.

        .. note::
            The permittivity is piecewise constant per element, so every element takes the value of exactly one polygon and material interfaces stay sharp. Bias dependent quantities are therefore evaluated at the element centroids.

        Args:
            frequency: The frequency at which to compute the permittivity tensor. The frequency must be in GHz.
            use_charge_transport_data: Whether to use the charge transport data to compute the permittivity tensor. Doing so will yield a :math:`\sigma(x,y,V)`. Make sure your mesh is appropriate for it.
            voltage_idx: The index of the voltage to use for the permittivity tensor.

        """
        omega = 2 * np.pi * frequency * self.reg.GHz

        self.epsilon_rf = np.zeros((self.basis.N, 1), dtype=np.complex128)

        # the self.photo_polygons is created so that idx 0 has higher priority over idx 1
        # Here, however, if we loop through the photo_polygons from idx 0 to idx N
        # the hierarchy on the boundaries will be inverted. That is,
        # lower lying polygons in hierarchy will dominate the boundaries. Therefore, we need to
        # loop over the inverted list of photo_polygons
        for photo_polygon in self.rf_photopolygons[::-1]:
            dofs_idxs = self._dofs_of(photo_polygon)

            self.epsilon_rf[dofs_idxs, 0] = photo_polygon.rf_eps(omega)

        if use_charge_transport_data == True:
            # Expand the epsilon_rf array to the voltage values
            # for photo_poly in self.rf_photopolygons:
            #     if isinstance(photo_poly, SemiconductorPolygon):
            #         N_bias_points = len(photo_poly.Ec)
            #         break

            N_bias_points = len(self.photodevice.charge["V"])

            if self.epsilon_rf is None:
                self.epsilon_rf = np.zeros((self.basis.N, N_bias_points), dtype=np.complex128)

            elif self.epsilon_rf.shape[1] == 1:
                # This is to account for the case where it has been first initialized
                # with the charge transport data so we extend the array to another dimension
                self.epsilon_rf = (
                    np.tile(self.epsilon_rf[:, 0], N_bias_points).reshape(N_bias_points, -1).T
                )

            for voltage_idx in range(N_bias_points):
                # Sweep through all the semiconductors
                # the self.photo_polygons is created so that idx 0 has higher priority over idx 1
                # Here, however, if we loop through the photo_polygons from idx 0 to idx N
                # the hierarchy on the boundaries will be inverted. That is,
                # lower lying polygons in hierarchy will dominate the boundaries. Therefore, we need to
                # loop over the inverted list of photo_polygons
                for photo_polygon in self.rf_photopolygons[::-1]:
                    dofs_idxs = self._dofs_of(photo_polygon)

                    if (
                        isinstance(photo_polygon, SemiconductorPolygon)
                        and photo_polygon.has_charge_transport_data
                    ):
                        x, y = self._centroids_of(photo_polygon)

                        self.epsilon_rf[dofs_idxs, voltage_idx] = photo_polygon.rf_eps(
                            omega
                        ).real + (
                            -1j
                            * (
                                self.e
                                * (
                                    self.photodevice.charge["N"][voltage_idx](x, y)
                                    * self.photodevice.charge["mun"][voltage_idx](x, y)
                                    + self.photodevice.charge["P"][voltage_idx](x, y)
                                    * self.photodevice.charge["mup"][voltage_idx](x, y)
                                )
                                / omega
                                / self.e0
                            )
                            .to(self.reg.dimensionless)
                            .magnitude
                        )
                    else:
                        self.epsilon_rf[dofs_idxs, voltage_idx] = photo_polygon.rf_eps(omega)

    def _elements_of(self, photo_polygon) -> np.ndarray:
        """
        The mesh elements owned by a photopolygon, together with those of any junction entity that falls inside it.
        """
        elements_idxs = np.asarray(self.mesh.subdomains[photo_polygon.name], dtype=int)

        # Sweep through all the junctions and see which fall within the semiconductor
        for name, junction_poly in self.junction_entities.items():
            if photo_polygon.polygon.contains(junction_poly):
                elements_idxs = np.concatenate(
                    (elements_idxs, np.asarray(self.mesh.subdomains[name], dtype=int))
                )

        return elements_idxs

    def _dofs_of(self, photo_polygon) -> np.ndarray:
        """
        The ``self.basis`` dofs owned by a photopolygon. With ``ElementTriP0`` there is exactly one dof per element, so this is a relabelling of :meth:`_elements_of`.
        """
        return self.basis.element_dofs[:, self._elements_of(photo_polygon)].flatten()

    def _centroids_of(self, photo_polygon) -> tuple[np.ndarray, np.ndarray]:
        """
        The ``(x, y)`` centroids of the elements owned by a photopolygon, ordered to match :meth:`_dofs_of`. Bias dependent data is sampled here because the permittivity is constant over each element.
        """
        triangles = self.mesh.t[:, self._elements_of(photo_polygon)]

        return (
            self.mesh.p[0, triangles].mean(axis=0),
            self.mesh.p[1, triangles].mean(axis=0),
        )

    def compute_modes(
        self,
        frequency: float = 10,
        voltage_idx: int = 0,
        num_modes: int = 1,
        order: int = 1,
        metallic_boundaries: list | str | bool = False,
        n_guess: float = 4.0,
        return_modes: bool = False,
        use_charge_transport_data: bool = False,
    ) -> Modes:
        """
        Compute the electromagnetic RF modes of a photonic device at a given frequency. The modes are computed via `FEMWELL`_.

        Args:
            frequency: The frequency at which to compute the modes. The frequency must be in GHz.
            voltage_idx: The index of the voltage to use for the permittivity tensor.
            num_modes: The number of modes to compute.
            order: Order of the basis functions to use in the EM solver.
            metallic_boundaries: The boundaries to treat as metallic. If `False`, no boundaries are treated as metallic. If `True`, all boundaries are treated as metallic. If a list of strings, the boundaries with the given names are treated as metallic. At the moment, the simulation window is treated as a square, therefore, the metallic boundaries can be ``left`, ``right``, ``top`` and ``bottom`` boundaries.
            n_guess: Initial guess for the effective index.
            return_modes: Whether to return the computed modes.
            use_charge_transport_data: Whether to use the charge transport data to compute the permittivity tensor. Doing so will yield a :math:`\sigma(x,y,V)`. Make sure your mesh is appropriate for it.

        Returns:
            The computed modes if `return_modes` is `True`.

        """

        self.get_epsilon_rf(
            frequency, use_charge_transport_data=use_charge_transport_data, voltage_idx=voltage_idx
        )

        modes = compute_modes(
            self.basis,
            self.epsilon_rf[:, voltage_idx],
            (self.c / (frequency * self.reg.GHz)).to(self.reg.micrometer).magnitude,
            mu_r=1,
            num_modes=num_modes,
            order=order,
            metallic_boundaries=metallic_boundaries,
            n_guess=n_guess,
        )

        self.modes = modes.sorted(lambda mode: mode.n_eff.real)

        if return_modes:
            return self.modes

    def plot_eps_rf(
        self,
        frequency: float = 10,
        voltage_idx: int = 0,
        use_charge_transport_data: bool = False,
        log_scale_im: bool = True,
        log_scale_re: bool = True,
        cmap="jet",
    ):
        """
        Plots the real and imaginary parts of the RF permittivity tensor.

        Args:
            frequency: The frequency at which to compute the permittivity tensor. The frequency must be in GHz.
            voltage_idx: The index of the voltage to use for the permittivity tensor.
            use_charge_transport_data: Whether to use the charge transport data to compute the permittivity tensor. Doing so will yield a :math:`\sigma(x,y,V)`.
            log_scale_im: Whether to plot the imaginary part of the permittivity tensor in logarithmic scale.
            log_scale_re: Whether to plot the real part of the permittivity tensor in logarithmic scale.
            cmap: The colormap to use for plotting.

        returns:
            fig: The matplotlib figure containing the plots.
            ax1: The axis for the imaginary part of the permittivity tensor.
            ax2: The axis for the real part of the permittivity tensor.

        """
        self.get_epsilon_rf(
            frequency=frequency, use_charge_transport_data=use_charge_transport_data
        )

        fig = plt.figure(figsize=(10, 6))
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)

        # Plot the polygons
        self.plot_polygons(
            ax=ax1,
        )
        self.plot_polygons(
            ax=ax2,
        )

        # Plot the imaginary part of the permittivity
        data_to_plot_im = self.epsilon_rf[:, voltage_idx].imag
        data_to_plot_re = self.epsilon_rf[:, voltage_idx].real

        if log_scale_im:
            data_to_plot_im = np.log10(-data_to_plot_im)
        if log_scale_re:
            data_to_plot_re = np.log10(data_to_plot_re)

        self.basis.plot(
            data_to_plot_im,
            cmap=cmap,
            colorbar=True,
            ax=ax1,
        )

        self.basis.plot(
            data_to_plot_re,
            cmap=cmap,
            colorbar=True,
            ax=ax2,
        )

        if use_charge_transport_data:
            if log_scale_im:
                ax1.set_title(
                    f"log10(Im(-$\epsilon_{{RF}}$)) at {frequency} GHz, V={self.photodevice.charge['V'][voltage_idx]} V"
                )
            else:
                ax1.set_title(
                    f"Im(-$\epsilon_{{RF}}$) at {frequency} GHz, V={self.photodevice.charge['V'][voltage_idx]} V"
                )
            if log_scale_re:
                ax2.set_title(
                    f"log10(Re($\epsilon_{{RF}}$)) at {frequency} GHz, V={self.photodevice.charge['V'][voltage_idx]} V"
                )
            else:
                ax2.set_title(
                    f"Re($\epsilon_{{RF}}$) at {frequency} GHz, V={self.photodevice.charge['V'][voltage_idx]} V"
                )

        else:
            if log_scale_im:
                ax1.set_title(f"log10(Im(-$\epsilon_{{RF}}$)) at {frequency} GHz")
            else:
                ax1.set_title(f"Im(-$\epsilon_{{RF}}$) at {frequency} GHz")
            if log_scale_re:
                ax2.set_title(f"log10(Re($\epsilon_{{RF}}$)) at {frequency} GHz")
            else:
                ax2.set_title(f"Re($\epsilon_{{RF}}$) at {frequency} GHz")

        ax1.set_xlabel("x (um)")
        ax1.set_ylabel("y (um)")

        ax2.set_xlabel("x (um)")
        ax2.set_ylabel("y (um)")

        return fig, ax1, ax2

    def plot_mode(
        self,
        mode: Mode,
        Nx: int = 50,
        Ny: int = 50,
        xmin: float = 0,
        xmax: float = 10,
        ymin: float = -10,
        ymax: float = +10,
        figsize: tuple[float, float] = (10, 4),
        wspace: float = 0.5,
        color_polygons: str = "white",
        color_integral_lines: str = "red",
        cmap: str = "jet",
        color_vectors: str = "black",
        plot_vectors: bool = True,
        vector_density: float = 1.0,
        axes=None,
        fig=None,
    ):
        """
        Plots the transverse components of the electric and magnetic fields of a mode.

        Args:
            mode: The mode object containing the electric and magnetic field data to be plotted.
            Nx: Number of grid points along the x-axis.
            Ny: Number of grid points along the y-axis.
            xmin: Minimum x-coordinate for the plot.
            xmax: Maximum x-coordinate for the plot.
            ymin: Minimum y-coordinate for the plot.
            ymax: Maximum y-coordinate for the plot.
            figsize: Figure size as (width, height).
            wspace: The amount of width reserved for blank space between subplots.
            color_polygons: Color of the polygons in the plot.
            color_integral_lines: Color of the integral lines in the plot.
            cmap: Colormap used for plotting the magnitude of the fields.
            color_vectors: Color of the vector field streamlines.
            plot_vectors: Whether to plot the vector field streamlines. If ``False``, intensity of the transverse fields will be plotted. The advantage of this is that the projection of the mode into a rectangular grid is quite heavy and if you request too many points it can take a while. Plotting the intensity only though is very fast.
            vector_density: Density of the vector field streamlines. Higher values result in more streamlines.
            axes: The matplotlib axes to plot on. If ``None``, new axes will be created. axes[0] is for the electric field and axes[1] is for the magnetic field.
            fig: The matplotlib figure to plot on. If ``None``, a new figure will be created.
        Returns:
            None: This method does not return any value. It generates a plot.

        .. note::

            * This method uses the `mode` object to interpolate the electric and magnetic fields onto a rectangular grid.
            * The fields are split into transverse and longitudinal components for plotting.
            * The resulting plot includes both the magnitude of the fields and their respective vector field streamlines.
            * Polygons and integral lines can be overlaid on the plot for additional context.
            * The projection into a rectangular grid is quite heavy, so it is recommended to use this method only for small regions to avoid large rectangular grids if you want to plot the vector fields.

        """
        if plot_vectors:
            grid_x, grid_y = np.meshgrid(np.linspace(xmin, xmax, Nx), np.linspace(ymin, ymax, Ny))

            # Transform the data onto a rectangular regular grid
            grid_data_E = np.zeros((Ny, Nx, 3), dtype=complex)
            grid_data_H = np.zeros((Ny, Nx, 3), dtype=complex)

            basis = mode.basis
            basis_fix = basis.with_element(ElementVector(ElementDG(ElementTriP1())))

            (et, et_basis), (ez, ez_basis) = basis.split(mode.E)
            (et_x, et_x_basis), (et_y, et_y_basis) = basis_fix.split(
                basis_fix.project(et_basis.interpolate(et))
            )

            coordinates = np.array([grid_x.flatten(), grid_y.flatten()])

            grid_data = np.array(
                (
                    et_x_basis.interpolator(et_x)(coordinates),
                    et_y_basis.interpolator(et_y)(coordinates),
                    ez_basis.interpolator(ez)(coordinates),
                )
            ).T

            grid_data_E = grid_data.reshape((*grid_x.shape, -1))

            (et, et_basis), (ez, ez_basis) = basis.split(mode.H)
            (et_x, et_x_basis), (et_y, et_y_basis) = basis_fix.split(
                basis_fix.project(et_basis.interpolate(et))
            )

            coordinates = np.array([grid_x.flatten(), grid_y.flatten()])

            grid_data = np.array(
                (
                    et_x_basis.interpolator(et_x)(coordinates),
                    et_y_basis.interpolator(et_y)(coordinates),
                    ez_basis.interpolator(ez)(coordinates),
                )
            ).T

            grid_data_H = grid_data.reshape((*grid_x.shape, -1))

        # Plot the data

        if axes is not None:
            fig = fig
            ax_E, ax_H = axes
        else:
            fig = plt.figure(figsize=figsize)
            gs = GridSpec(1, 2, wspace=wspace)

            ax_E = fig.add_subplot(gs[0, 0])
            ax_H = fig.add_subplot(gs[0, 1])

        for ax, mfield, label in zip(
            [ax_E, ax_H], [mode.E, mode.H], [r"$|E_t(x,y)|$", r"$|H_t(x,y)|$"]
        ):
            (mfield_x, mfield_y), _ = mode.basis.interpolate(mfield)
            mfield_mod = np.sqrt(np.abs(mfield_x) ** 2 + np.abs(mfield_y) ** 2)

            plot_basis = mode.basis.with_element(ElementDG(ElementTriP1()))
            mfield_plot = plot_basis.project(mfield_mod)

            plot_basis.plot(mfield_plot, ax=ax, cmap=cmap, colorbar=True, shading="gouraud")

            self.plot_polygons(
                fig=fig,
                ax=ax,
                color_polygon=color_polygons,
                color_line=color_integral_lines,
            )

            ax.set_xlim(xmin, xmax)
            ax.set_ylim(ymin, ymax)

            ax.set_xlabel("x (um)")
            ax.set_ylabel("y (um)")

            ax.set_title(label)

        if plot_vectors:
            for ax, data, label in zip(
                [ax_E, ax_H], [grid_data_E, grid_data_H], [r"$|E(x,y)|$", r"$|H(x,y)|$"]
            ):
                # ax.imshow(
                #     np.sqrt(np.sum(np.abs(data)**2, axis=2)),
                #     origin="lower",
                #     extent=[xmin, xmax, ymin, ymax],
                #     cmap=cmap,
                #     interpolation="bicubic",
                #     aspect="auto",
                # )

                ax.streamplot(
                    grid_x,
                    grid_y,
                    data.real[:, :, 0],
                    data.real[:, :, 1],
                    color=color_vectors,
                    linewidth=0.5,
                    density=vector_density,
                )

    def plot_polygons(
        self,
        color_polygon="black",
        color_line="green",
        color_junctions="blue",
        fig=None,
        ax=None,
        equal_aspect: bool = False,
    ):
        """
        Plots the polygon and line entities in the simulation window.

        Args:
            color_polygon: The color of the polygons in the plot.
            color_line: The color of the line entities in the plot.
            color_junctions: The color of the junction entities in the plot.
            fig: The matplotlib figure to plot on. If `None`, a new figure is created.
            ax: The matplotlib axis to plot on. If `None`, a new axis is created.
            equal_aspect: If ``True``, the x and y axes are scaled with a 1:1 aspect ratio.
        """
        if fig is None and ax is None:
            fig = plt.figure()
            ax = fig.add_subplot(111)

        for name, poly in self.entities.items():
            if isinstance(poly, Polygon):
                ax.plot(
                    *poly.exterior.xy,
                    color=color_polygon if "junction" not in name else color_junctions,
                )
            elif isinstance(poly, Line):
                ax.plot(*poly.xy, color=color_line)

        if equal_aspect:
            ax.set_aspect("equal", adjustable="box")

    def plot_mesh(self, plot_polygons: bool = True, ax=None):
        """
        Plots the mesh of the photonic device.

        Args:
            plot_polygons: Whether to plot the polygons on the mesh. If ``True`` it will call the :meth:`imodulator.RFSimulator.plot_polygons` method.

        Returns:
            fig: The matplotlib figure.
            ax: The matplotlib axis.
        """

        if ax is None:
            ax = draw_mesh2d(self.mesh)
        else:
            draw_mesh2d(self.mesh, ax=ax)
        ax.set_axis_on()

        fig = ax.get_figure()

        if plot_polygons:
            self.plot_polygons(color_polygon="red", fig=fig, ax=ax)

        return fig, ax

    def get_currents(self, mode: Mode):
        r"""
        This function calculates the currents in every polygon marked as ``calculate_current = True`` via:

        .. math::


            i_0 = \int_{\partial \Omega} \mathbf{n} \times \mathbf{H} \cdot d\mathbf{s}

        Note that every field returned by `FEMWELL`_ is **power normalized by orthogonality relations**. Therefore, if you're using a symmetry plane, you have to take into account that this code will return a value taking into account that HALF the field has power 1. Please adjust the values to your specific case/symmetry. The reccomended approach is to calculate once with the full structure and then find the proper scaling factors.

        Args:
            mode: The mode object containing the electric and magnetic field data to be used for the calculation.

        Returns:
            p0 (complex): The power normalization factor. It will be **very** close to 1, but it is not exactly 1 due to the numerical integration.
            currents (dict): A dictionary containing the calculated currents for each polygon.
            impedances (dict): A dictionary containing the calculated impedances for each polygon.
        """

        @Functional(dtype=np.complex128)
        def current_form(w):
            """
            What this does is it takes the normal vector to the boundary and rotates it 90deg
            Then takes the inner product with the magnetic field in it's complex form
            """
            return inner(np.array([w.n[1], -w.n[0]]), w.H)

        p0 = calculate_scalar_product(
            mode.basis, np.conjugate(mode.E), mode.basis, np.conjugate(mode.H)
        )  # The conjugate is due to femwell internal definition as conj(E) x H

        (ht, ht_basis), (hz, hz_basis) = mode.basis.split(mode.H)

        currents = {}
        impedances = {}

        for line_name, line in self.line_entities.items():
            if "line_current" in line_name:
                facet_basis = ht_basis.boundary(facets=self.mesh.boundaries[line_name])
                i0 = current_form.assemble(facet_basis, H=facet_basis.interpolate(ht))
                currents[line_name] = i0
                impedances[line_name] = p0 / np.abs(i0) ** 2

        return p0, currents, impedances

    def get_RLGC(self, mode: Mode, i0: complex = 1.0, v0: complex = 1.0):
        r"""
        This function calculates the RLGC parameters calculated from waveguide circuit theory for a TEM field. 

        The :math:`i_0` and :math:`v_0` values provided should be the values of current and voltage across the signal and ground tracks of the equivalent transmission line. This is not always straightforward, particularly if you're dealing with multiconductor transmission lines. It is reccomended to use this formalism only when you have a good equivalent transmission line of the present mode.

        Please note that every field returned by `FEMWELL`_ is power normalized by orthogonality relations. Therefore, if you're using a symmetry plane, you have to take into account that this code will return a value taking into account that HALF the field has power 1. Please adjust the values to your specific case/symmetry. The reccomended approach is to calculate once with the full structure and then find the proper scaling factors.

        The RLGC parameters are calculated according to :cite:t:`marks_general_1992`:

        .. math::

            C = \frac{1}{|v_0|^2} \left[ \int_S \Re\{\epsilon_{RF}\} |E_t|^2dS - \int_S \Re\{\mu_{RF}\}|H_z|^2 dS \right] \\
            L = \frac{1}{|i_0|^2} \left[ \int_S \Re\{\mu_{RF}\} |H_t|^2dS - \int_S \Re\{\epsilon_{RF}\}|E_z|^2 dS \right] \\
            G = \frac{\omega}{|v_0|^2} \left[ \int_S \Im\{\epsilon_{RF}\} |E_t|^2dS + \int_S \Im\{\mu_{RF}\}|H_z|^2 dS \right] \\
            R = \frac{\omega}{|i_0|^2} \left[ \int_S \Im\{\mu_{RF}\} |H_t|^2dS + \int_S \Im\{\epsilon_{RF}\}|E_z|^2 dS \right] 
        
        Args:
            mode: The mode object containing the electric and magnetic field data to be used for the calculation.
            i0: The current value to use for the calculation.
            v0: The voltage value to use for the calculation.

        Returns:
            R (float): The resistance per unit length in Ohms per micrometer.
            L (float): The inductance per unit length in Henrys per micrometer.
            G (float): The conductance per unit length in Siemens per micrometer.
            C (float): The capacitance per unit length in Farads per micrometer.
        """

        reg = self.photodevice.reg
        frequency = 3e8 / mode.wavelength / 1e3 * reg.GHz
        omega = 2 * np.pi * frequency
        e0 = self.photodevice.e0
        mu0 = self.photodevice.mu0
        c = self.photodevice.c

        @Functional(dtype=np.complex64)
        def C_form(w):

            return (
                1
                / np.abs(w.v0) ** 2
                * (
                    np.real(w.epsilon) * inner(w.et, np.conj(w.et))
                    - np.real(w.mu) * inner(w.hz, np.conj(w.hz))
                )
            )

        @Functional(dtype=np.complex64)
        def L_form(w):

            return (
                1
                / np.abs(w.i0) ** 2
                * (
                    np.real(w.mu) * inner(w.ht, np.conj(w.ht))
                    - np.real(w.epsilon) * inner(w.ez, np.conj(w.ez))
                )
            )

        @Functional(dtype=np.complex64)
        def G_form(w):
            # The minus sign account for the fact that in the paper they define eps = eps_r-1j*eps_i
            # whereas with python we have eps = eps_r+1j*eps_i.
            return (
                -w.omega
                / np.abs(w.v0) ** 2
                * (
                    np.imag(w.epsilon) * inner(w.et, np.conj(w.et))
                    + np.imag(w.mu) * inner(w.hz, np.conj(w.hz))
                )
            )

        @Functional(dtype=np.complex64)
        def R_form(w):
            # The minus sign account for the fact that in the paper they define eps = eps_r-1j*eps_i
            # whereas with python we have eps = eps_r+1j*eps_i.
            return (
                -w.omega
                / np.abs(w.i0) ** 2
                * (
                    np.imag(w.epsilon) * inner(w.ez, np.conj(w.ez))
                    + np.imag(w.mu) * inner(w.ht, np.conj(w.ht))
                )
            )

        (ht, ht_basis), (hz, hz_basis) = mode.basis.split(mode.H)
        (et, et_basis), (ez, ez_basis) = mode.basis.split(mode.E)

        epsilon = mode.epsilon_r

        basis_t = et_basis
        basis_z = ez_basis
        basis_eps = mode.basis_epsilon_r

        # Be careful with the units!!
        # In this case just make sure you adjust the length unit to micrometers
        # everything else can stay as is.

        C = C_form.assemble(
            mode.basis,
            epsilon=basis_eps.interpolate(epsilon * e0.to(reg.farad / reg.micrometer).magnitude),
            mu=mu0.to(reg.henry / reg.micrometer).magnitude,
            i0=i0,
            omega=omega.to(reg.second**-1).magnitude,
            v0=v0,
            et=basis_t.interpolate(et),
            ez=basis_z.interpolate(ez),
            ht=basis_t.interpolate(ht),
            hz=basis_z.interpolate(hz),
        )

        L = L_form.assemble(
            mode.basis,
            epsilon=basis_eps.interpolate(epsilon * e0.to(reg.farad / reg.micrometer).magnitude),
            mu=mu0.to(reg.henry / reg.micrometer).magnitude,
            i0=i0,
            omega=omega.to(reg.second**-1).magnitude,
            v0=v0,
            et=basis_t.interpolate(et),
            ez=basis_z.interpolate(ez),
            ht=basis_t.interpolate(ht),
            hz=basis_z.interpolate(hz),
        )

        G = G_form.assemble(
            mode.basis,
            epsilon=basis_eps.interpolate(epsilon * e0.to(reg.farad / reg.micrometer).magnitude),
            mu=mu0.to(reg.henry / reg.micrometer).magnitude,
            i0=i0,
            omega=omega.to(reg.second**-1).magnitude,
            v0=v0,
            et=basis_t.interpolate(et),
            ez=basis_z.interpolate(ez),
            ht=basis_t.interpolate(ht),
            hz=basis_z.interpolate(hz),
        )

        R = R_form.assemble(
            mode.basis,
            epsilon=basis_eps.interpolate(epsilon * e0.to(reg.farad / reg.micrometer).magnitude),
            mu=mu0.to(reg.henry / reg.micrometer).magnitude,
            i0=i0,
            omega=omega.to(reg.second**-1).magnitude,
            v0=v0,
            et=basis_t.interpolate(et),
            ez=basis_z.interpolate(ez),
            ht=basis_t.interpolate(ht),
            hz=basis_z.interpolate(hz),
        )

        # The units returned are:
        # mOhm/um
        # picoHenry/um
        # picoSiemens/um
        # femtofarad/um

        return (
            R.real / 1e-3 * self.reg.milliohm / self.reg.micrometer,
            L.real / 1e-12 * self.reg.picohenry / self.reg.micrometer,
            G.real / 1e-15 * self.reg.femtosiemens / self.reg.micrometer,
            C.real / 1e-15 * self.reg.femtofarad / self.reg.micrometer,
        )

    def get_power_loss_per_polygon(self, mode: Mode, frequency: float):
        r"""
        This function returns the power loss per polygon as described in :cite:t:`pozar_microwave_2012` eq. 1.92. The result is given in W/cm:

        .. math::

            P_l = \int_V \frac{\sigma}{2}|E|^2dv + \frac{\omega}{2}\int_V(\Im\{\epsilon\}|E|^2 + \Im\{\mu\}|H|^2)dv


        .. warning:: This part is not developed yet.

        Args:
            mode: The mode object containing the electric and magnetic field data to be used for the calculation.
            frequency: The frequency at which to compute the power loss. The frequency must be in GHz.
        Returns:
            power_lost_all (dict): A dictionary containing the power lost per polygon
        """

        warnings.warn(
            "The loss per polygon functionality is under development!! Results are not correct."
        )

        from skfem.helpers import dot

        @Functional
        def factor(w):
            return w["epsilon"] * (
                dot(np.conj(w["E"][0]), w["E"][0]) + np.conj(w["E"][1]) * w["E"][1]
            )

        power_lost_all = {}
        for photo_polygon in self.rf_photopolygons:
            # Retrieve all vertice idxs that belong to the polygon
            elements = self.mesh.subdomains[photo_polygon.name]

            basis = mode.basis.with_elements(elements)
            basis_epsilon_r = mode.basis_epsilon_r.with_elements(elements)
            power_lost = (
                (2 * np.pi * frequency * 1e9)
                / 2
                * 8.85e-12
                * 1e-6  # To get F/um
                * factor.assemble(
                    basis,
                    E=basis.interpolate(mode.E),
                    epsilon=basis_epsilon_r.interpolate(mode.epsilon_r),
                )
            ).imag * 1e4  # To get W/cm

            power_lost_all[photo_polygon.name] = power_lost * self.reg.watt / self.reg.centimeter

        return power_lost_all

    def confinement_factor(self, mode: Mode, polygons: str | list[str]) -> float:
        r"""
        The fraction of the mode's electric-field energy that sits inside the given polygons:

        .. math::

            \Gamma = \frac{\int_{S_{poly}} |E|^2 dS}{\int_{S} |E|^2 dS}

        where :math:`|E|^2 = |E_t|^2 + |E_z|^2` and :math:`S` is the whole meshed cross-section. This is the geometric (energy) confinement factor, not the group-velocity-corrected optical one, so it is bounded to :math:`[0, 1]` and is meant for identifying which physical structure a mode belongs to -- e.g. telling an electrode mode confined to the waveguide mesa apart from a delocalised substrate or box mode.

        Args:
            mode: The mode object containing the electric field data to be used for the calculation.
            polygons: Name, or list of names, of the polygons whose combined area forms the confinement region. Each must be a subdomain of the mesh.

        Returns:
            confinement (float): The fraction of :math:`|E|^2` inside ``polygons``, between 0 and 1.
        """

        @Functional
        def energy(w):
            return inner(np.conj(w["E"][0]), w["E"][0]) + np.conj(w["E"][1]) * w["E"][1]

        names = [polygons] if isinstance(polygons, str) else list(polygons)

        missing = [name for name in names if name not in self.mesh.subdomains]
        if missing:
            raise KeyError(
                f"polygons {missing} are not subdomains of the RF mesh. "
                f"Available: {sorted(self.mesh.subdomains)}"
            )

        elements = np.unique(
            np.concatenate([np.asarray(self.mesh.subdomains[name], dtype=int) for name in names])
        )
        if elements.size == 0:
            return 0.0

        sub_basis = mode.basis.with_elements(elements)

        inside = energy.assemble(sub_basis, E=sub_basis.interpolate(mode.E)).real
        total = energy.assemble(mode.basis, E=mode.basis.interpolate(mode.E)).real

        return float(inside / total) if total != 0 else float("nan")

    def get_S(
        self,
        gamma: Quantity,
        Z: Quantity,
        ZL: float = 50.0,
        ZS: float = 50.0,
        L: float = 1e3,
    ):
        r""" 
        We calculate the S parameters based on transmission line theory :cite:t:`rizzi_microwave_1988`, starting from the ABCD matrix and going to S parameters:

        .. math::

            S_{11} = \frac{AZ_L + B - CZ_L*Z_S - DZ_S}{AZ_L + B + CZ_LZ_S + DZ_S} \\
            S_{22} = \frac{2\sqrt{Z_S Z_L}}{AZ_L + B + CZ_LZ_S + DZ_S}

        Args:
            gamma: The propagation constant. Must be in um**-1
            Z: The characteristic impedance. Must be in Ohm.
            ZL: The load impedance. Defaults to 50 Ohm.
            ZS: The source impedance. Defaults to 50 Ohm.
            L: The length of the transmission line. Defaults to 1000 um.

        Returns:
            S11: The S11 parameter.
            S12: The S12 parameter
        """

        ZL = ZL * self.reg.ohm
        ZS = ZS * self.reg.ohm
        L = L * self.reg.micrometer
        gamma = gamma * self.reg.micrometer**-1
        Z = Z * self.reg.ohm

        self.S = np.zeros((2, 2), dtype=complex)

        # This is to adhere to the same gamma convention of the RF theory where gamma = alpha + 1j*beta
        # whereas here we deal with k = beta - 1j*alpha
        k = np.abs(gamma.imag) + 1j * np.abs(gamma.real)

        A = np.cosh(k * L)
        B = Z * np.sinh(k * L)
        C = np.sinh(k * L) / Z
        D = np.cosh(k * L)

        S11 = (A * ZL + B - C * ZL * ZS - D * ZS) / (A * ZL + B + C * ZL * ZS + D * ZS)
        S12 = (2 * np.sqrt(ZS * ZL)) / (A * ZL + B + C * ZL * ZS + D * ZS)

        return (
            S11.to(self.reg.dimensionless).magnitude,
            S12.to(self.reg.dimensionless).magnitude,
        )


def get_named_boundaries_in_refined_mesh(
    old_mesh,
    new_mesh,
    N=100,
):
    """
    For each named boundary in old_mesh, it find the corresponding facets in the new mesh that lie along the same geometric boundary as those in the old mesh. It does so by finding the N nearest midpoints of the new facets to the midpoints of the old facets, and then checking which of those midpoints lie along the old facet.

    Parameters
    -----------
    old_mesh : skfem.Mesh
        The coarse mesh with named boundaries.
    new_mesh : skfem.Mesh
        The refined mesh.
    N : int
        The number of nearest midpoints to consider for each old facet midpoint.

    Returns
    --------
    new_boundaries : dict
        A dictionary where keys are the named boundaries from old_mesh and values are lists of facet indices in new_mesh that correspond to those boundaries.
    """

    from scipy.spatial import KDTree
    from skfem.generic_utils import OrientedBoundary
    from shapely.geometry import Polygon

    p_old = old_mesh.p
    p_new = new_mesh.p

    # midpoints of fine facets
    new_midpoints = np.mean(p_new[:, new_mesh.facets], axis=1).T

    tree = KDTree(new_midpoints)

    new_boundaries = {}
    new_orientations = {}
    for named_boundary in old_mesh.boundaries.keys():
        new_boundaries[named_boundary] = []
        new_orientations[named_boundary] = []

        old_facets_idx = old_mesh.boundaries[named_boundary]
        old_midpoints = np.mean(p_old[:, old_mesh.facets[:, old_facets_idx]], axis=1).T

        # We now find the N nearest fine midpoints to that are closest to each of the midpoints of the old facets of a given boundary
        dists, idx = tree.query(old_midpoints, k=N)

        # Now we loop over each of the N new midpoints and see which of those actually lie in the along the facet of the old midpoint

        for i, old_facet_idx in enumerate(old_facets_idx):
            for j in range(N):
                new_midpoint = new_midpoints[idx[i, j]]
                # Check if the new midpoint is on the old facet
                facet_nodes = old_mesh.facets[:, old_facet_idx]
                points_facet = old_mesh.p[:, facet_nodes]

                vec_paralell = points_facet[:, 1] - points_facet[:, 0]
                vec_normal = np.array([-vec_paralell[1], vec_paralell[0]])

                # Check if the new midpoint is on the old facet
                # It is on the facet if the vector of one of the endpoints of the old facet to the new midpoint is perpendicular to the normal vector of the old facet
                vec_endpoint_to_newmid = new_midpoint - points_facet[:, 0]

                # normalize the vectors
                res = np.dot(vec_endpoint_to_newmid, vec_normal) / np.linalg.norm(vec_normal)

                if abs(res) < 1e-10:
                    # Project new midpoint onto the facet direction
                    t = np.dot(vec_endpoint_to_newmid, vec_paralell) / np.dot(
                        vec_paralell, vec_paralell
                    )

                    # Check if it's within the segment
                    if 0 - 1e-12 <= t <= 1 + 1e-12:
                        # We now know that it belongs to the same facet as the old mesh facet. Let's just order the points in the new facet so that

                        vec_old_facet = points_facet[:, 1] - points_facet[:, 0]
                        new_facet_nodes = new_mesh.facets[:, idx[i, j]]
                        points_new_facet = new_mesh.p[:, new_facet_nodes]
                        vec_new_facet = points_new_facet[:, 1] - points_new_facet[:, 0]

                        # If the two vectors have the same direction, we keep the same orientation
                        if np.dot(vec_old_facet, vec_new_facet) < 0:
                            new_mesh.facets[:, idx[i, j]] = new_mesh.facets[
                                ::-1, idx[i, j]
                            ]  # Flip the facet orientation in the new mesh

                        # Now we need to find the ori attribute. We will do this by finding the element of the new facet which is inside the element of the OrientedBoundary facet in the old mesh. Then we store that index as the ori attribute

                        old_boundary = old_mesh.boundaries[named_boundary]
                        element_old_facet = old_mesh.f2t[old_boundary.ori[i], old_facet_idx]
                        points_of_element_old_facet = old_mesh.p[
                            :, old_mesh.t[:, element_old_facet]
                        ]
                        old_triangle = Polygon(points_of_element_old_facet.T)

                        elements_new_facet = new_mesh.f2t[:, idx[i, j]]

                        triangles = []
                        for element_new_facet in elements_new_facet:
                            if element_new_facet == -1:
                                continue
                            points_of_element_new_facet = new_mesh.p[
                                :, new_mesh.t[:, element_new_facet]
                            ]
                            new_triangle = Polygon(points_of_element_new_facet.T)
                            triangles.append(new_triangle)

                        for k, triangle in enumerate(triangles):
                            if old_triangle.contains(triangle.centroid):
                                new_orientations[named_boundary].append(k)

                        new_boundaries[named_boundary].append(int(idx[i, j]))

        ## Define them as an OrientedBoundary
        for named_boundary in new_boundaries.keys():
            new_boundary = new_boundaries[named_boundary]
            new_orient = new_orientations[named_boundary]

            new_boundaries[named_boundary] = OrientedBoundary(
                np.array(new_boundary, dtype=int),
                np.array(new_orient, dtype=int),
            )

    return new_boundaries
