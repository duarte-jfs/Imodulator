from matplotlib import pyplot as plt
import numpy as np

from shapely.geometry import (
    LineString,
	box
)

import imodulator

from utils import IMOS_twg
from imodulator.ChargeSimulator import ChargeSimulatorNN
from imodulator.OpticalSimulator import OpticalSimulatorMODE
from imodulator.RFSimulator import RFSimulator

imos = IMOS_twg()
imos.update_parameters(
	t_top_bc = 50,
	t_bot_substrate = 50
)

a=LineString([[-imos.d_wgs/2-imos.w_wg/2,imos.t_pmetal],
              [-imos.d_wgs/2-imos.w_wg/2, imos.h_upper_wg+imos.t_ncontact1 + imos.t_ncontact2]]) #simulation line

charge=ChargeSimulatorNN(device=imos.device,simulation_line=a,bias_start_stop_step=[-6,0,6])

charge.NNinputf.execute(show_log=False,convergenceCheck=True,convergence_check_mode="continue")

charge.load_output_data()

charge.move_to_new_mesh(xmin = -9,xmax=-8)

rf_sim = RFSimulator(imos.device, simulation_window=box(-100, -50, 0, 40))
rf_sim.make_mesh()

print(rf_sim.mesh.nelements)

rf_sim.compute_modes(frequency = 10,
                metallic_boundaries = ['left', 'bottom', 'right', 'top'],
                voltage_idx = 0,
                n_guess = 3,
                num_modes = 2,
                order = 1,
                return_modes = True,
                use_charge_transport_data=True)

for i in range(len(rf_sim.modes)):
    print(f'Effective index - mode {i}: {rf_sim.modes[i].n_eff.real:.4f}')
    print(f'loss - mode {i}: {rf_sim.modes[i].calculate_propagation_loss(1e4):.2f} dB/cm')
    print('#------------------------------------------#')