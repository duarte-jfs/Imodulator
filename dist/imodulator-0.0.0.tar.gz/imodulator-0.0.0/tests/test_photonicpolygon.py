# %%
from __future__ import annotations

import copy
import warnings
from collections import OrderedDict

import numpy as np
from femwell.maxwell.waveguide import Mode, Modes, compute_modes
from femwell.mesh import mesh_from_OrderedDict
from matplotlib import pyplot as plt
from matplotlib.gridspec import GridSpec
from shapely.geometry import (LinearRing, LineString, MultiLineString,
                              MultiPolygon, Polygon)
from shapely.ops import clip_by_rect, linemerge, unary_union
from skfem import Basis, ElementDG, ElementTriP1, ElementVector, Functional
from skfem.helpers import inner
from skfem.io.meshio import from_meshio
from skfem.visuals.matplotlib import draw_mesh2d

from imodulator import PhotonicDevice
from imodulator.ElectroOpticalModel import ElectroOpticalModel
from imodulator.PhotonicPolygon import (InsulatorPolygon, MaterialPolygon,
                                        MetalPolygon, SemiconductorPolygon)

PhotonicPolygon = SemiconductorPolygon | MetalPolygon | InsulatorPolygon
Line = LineString | MultiLineString | LinearRing

import sys

#
from utils import SMART_wg, get_broadband_index

sys.path.insert(1, r"D:\Repos\eo-modulator-simulation")
import enlighten
# sys.path.insert(1, r"C:\Users\alika\Documents\Repos\ingaasp-eo-modulator-design")
import InGaAsP_models

from imodulator.ElectroOpticalModel import InGaAsPElectroOpticalModel

# %%

def get_stack_properties(wl = 1550, etched = False):
    stack_properties_PIN = {
        'layer1': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(1e16, 300, 0.53, 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 20/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0.53, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer2': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(1e18, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 750/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0.53, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer3': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(1e18, 300, 0.53, 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 20/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0.53, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer4': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(5e17, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 300/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer5': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(6e16, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 200/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer6': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(6e16, 300, 0.53, 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 500/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0.53, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer7': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(6e17, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 20/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0., 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer8': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(5e17, 300, 0.53, 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 30/1e3 if not etched else 0/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0.53, 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer9': {'eps_opt':get_broadband_index(
            InGaAsP_models.n_InGaAsP(5e17, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 20/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0., 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer10': {'eps_opt':get_broadband_index(
            InGaAsP_models.p_InGaAsP(1e17, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 320/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0., 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},

        'layer11': {'eps_opt':get_broadband_index(
            InGaAsP_models.p_InGaAsP(1e18, 300, 0., 1550),
            wl_min=wl, wl_max = wl+10, N_samples=1)[0,1],
                'thickness': 1100/1e3,
                'eo_model': InGaAsPElectroOpticalModel,
                'eo_kwargs': {'y': 0., 'T': 300, 'bandgap_model': 'jain', 'BF_model': 'vinchant', 'growing_direction': 'y'}},
        
    }

    return stack_properties_PIN


eo_mesh_settings_PIN = {
    'metal': {'resolution': 0.35, 'SizeMax': 0.5, 'distance': 1},
    'planarization': {'resolution': 1, 'SizeMax': 1, 'distance': 0.1},
    'background': {'resolution': 3, 'SizeMax': 50, 'distance': 0.1},
    'layer1':  {'resolution': 0.07, 'SizeMax': 0.1, 'distance': 0.25},
    'layer2':  {'resolution': 0.1, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer3':  {'resolution': 0.07, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer4':  {'resolution': 0.07, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer5':  {'resolution': 0.07, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer6':  {'resolution': 0.10, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer7':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer8':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer9':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer10':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer11':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'substrate':  {'resolution': 3, 'SizeMax': 1, 'distance': 0.1},
}

rf_mesh_settings_PIN = {
    'metal': {'resolution': 0.35, 'SizeMax': 0.5, 'distance': 1},
    'planarization': {'resolution': 1, 'SizeMax': 1, 'distance': 0.1},
    'background': {'resolution': 3, 'SizeMax': 50, 'distance': 0.1},
    'layer1':  {'resolution': 0.15, 'SizeMax': 0.8, 'distance': 0.5},
    'layer2':  {'resolution': 0.1, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer3':  {'resolution': 0.05, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer4':  {'resolution': 0.05, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer5':  {'resolution': 0.10, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer6':  {'resolution': 0.15, 'SizeMax': 0.1, 'distance': 0.1,},
    'layer7':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer8':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer9':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer10':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'layer11':  {'resolution': 0.1, 'SizeMax': 1, 'distance': 0.1,},
    'substrate':  {'resolution': 3, 'SizeMax': 1, 'distance': 0.1},
}

optical_mesh_settings_PIN = {
    'metal': {'resolution': 0.1, 'SizeMax': 0.2, 'distance': 1.5},
    'planarization': {'resolution': 0.15, 'SizeMax': 1, 'distance': 0.1},
    'background': {'resolution': 0.3, 'SizeMax': 5, 'distance': 0.1},
    'layer1':  {'resolution': 0.1, 'SizeMax': 0.1, 'distance': 0.3,},
    'layer2':  {'resolution': 0.04, 'SizeMax': 0.1, 'distance': 0.,},
    'layer3':  {'resolution': 0.04, 'SizeMax': 0.1, 'distance': 0.,},
    'layer4':  {'resolution': 0.04, 'SizeMax': 0.1, 'distance': 0.,},
    'layer5':  {'resolution': 0.02, 'SizeMax': 0.1, 'distance': 0.,},
    'layer6':  {'resolution': 0.02, 'SizeMax': 1, 'distance': 0.,},
    'layer7':  {'resolution': 0.02, 'SizeMax': 1, 'distance': 0.,},
    'layer8':  {'resolution': 0.03, 'SizeMax': 1, 'distance': 0.,},
    'layer9':  {'resolution': 0.050, 'SizeMax': 1, 'distance': 0.,},
    'layer10':  {'resolution': 0.05, 'SizeMax': 1, 'distance': 0.,},
    'layer11':  {'resolution': 0.05, 'SizeMax': 1, 'distance': 0.,},
    'substrate':  {'resolution': 0.3, 'SizeMax': 5, 'distance': 0.},
}

# for i in range(1,12):
#     optical_mesh_settings_PIN[f'layer{i}']['resolution'] = 1

for i in [5,6,7,8,9,10]:
    optical_mesh_settings_PIN[f'layer{i}']['resolution'] = optical_mesh_settings_PIN[f'layer{i}']['resolution']*0.3

# %%
wg_unetched = SMART_wg(
    get_stack_properties(wl = 1550, etched = False),
    optical_mesh_settings_PIN,
    eo_mesh_settings_PIN,
    rf_mesh_settings_PIN,
    w_wg = 1.5,
    N_overetch=0.25,
    w_window=6,
    h_bottom = 2,
    h_top = 2
)

# wg_unetched.device.plot_polygons()
# plt.show()
# input()
# %%

class OpticalSimulatorMODE:
    #The api import can be cleaner dunno how
    
    # The default paths for windows
    """
    Base class for Mode simulation of a PhotonicDevice based on Lumerical MODE
    """

    def __init__(
        self,
        device: PhotonicDevice,
        simulation_window: Polygon | None = None,
        include_metals: bool = True,
    ):

        '''
        __init__: Initializes the OpticalSimulatorMODE class with nessecary parameters for the sim and initiate the lumerical mode application.
        device: the PhotonicDevice to simulate
        simulation_window: the window that we use to apply to the simulation.
        include_metals: if True, the metals will be included in the simulation. If False, the metals will be ignored.
        
        To_do: 
        Underscores for non-user functions  
        Definitions for kwargs should be same as femwell to prevent confusion
        Priority is defined by the order, it should follow the same 
        Permitivity tensor to input n,k values
        '''
        import importlib.util
        spec = importlib.util.spec_from_file_location(
        'lumapi', 'C:\\Program Files\\Lumerical\\v232\\api\\python\\lumapi.py')
        # Functions that perform the actual loading
        self.lumapi= importlib.util.module_from_spec(spec)  # windows
        spec.loader.exec_module(self.lumapi) #windows
        self.photodevice = device
        self.reg = self.photodevice.reg

        self.e = 1.602176634e-19 * self.reg.coulomb
        self.e0 = 8.854e-12 * self.reg.farad * self.reg.meter**-1
        self.c = 3e8 * self.reg.meter * self.reg.second**-1  # m s^-1
        self.mu0 = (
            4 * np.pi * 1e-7 * self.reg.henry / self.reg.meter
        )  # vacuum magnetic permeability

        self.simulation_window = simulation_window

        self.optical_photopolygons = copy.deepcopy(self.photodevice.photo_polygons)

        # remove metals if not include_metals
        if not include_metals:
            self.optical_photopolygons = [
                poly
                for poly in self.optical_photopolygons
                if not isinstance(poly, MetalPolygon)
            ]

        self.line_entities = OrderedDict() #?
        self.polygon_entities = OrderedDict() #?
        self.junction_entities = OrderedDict() #?
        self.resolutions = dict() 


        # THIS NEEDS A REFACTOR!!!

        if simulation_window is None:
            for name, poly in self.photodevice.junction_entities.items():
                self.junction_entities[name] = poly

        elif simulation_window is not None:
            #Enforce the simulation plane to be a rectangle
            if not np.isclose(
                simulation_window.minimum_rotated_rectangle.area, simulation_window.area
            ):
                raise ValueError("symmetry plane must be a rectangle")

            # Cut all photopolygons by the simulation plane
            idxs_to_pop = []
            for i, poly in enumerate(self.optical_photopolygons):
                if poly.polygon.intersects(
                    simulation_window
                ) and not simulation_window.contains(poly.polygon):
                    poly_tmp = clip_by_rect(poly.polygon, *simulation_window.bounds)

                    if poly_tmp.is_empty:
                        idxs_to_pop.append(i)
                    else:
                        self.optical_photopolygons[i].polygon = poly_tmp

                elif not poly.polygon.intersects(simulation_window):
                    idxs_to_pop.append(i)

            for index in sorted(idxs_to_pop, reverse=True):
                del self.optical_photopolygons[index]

        for polygon in self.optical_photopolygons:
            self.polygon_entities[polygon.name] = polygon.polygon
        # We now have all the photopolygons cut by the plane. Let us finally add the boundaries

        surf_bounds = self.polygon_entities["background"].bounds

        left = LineString(
            [(surf_bounds[0], surf_bounds[1]), (surf_bounds[0], surf_bounds[3])]
        )

        bottom = LineString(
            [(surf_bounds[0], surf_bounds[1]), (surf_bounds[2], surf_bounds[1])]
        )

        right = LineString(
            [(surf_bounds[2], surf_bounds[1]), (surf_bounds[2], surf_bounds[3])]
        )

        top = LineString(
            [(surf_bounds[0], surf_bounds[3]), (surf_bounds[2], surf_bounds[3])]
        )
        #Entities not needed for MODE probably
        self.line_entities["left"] = left
        self.line_entities["bottom"] = bottom
        self.line_entities["right"] = right
        self.line_entities["top"] = top

        self.entities = OrderedDict(
            list(self.line_entities.items())
            + list(self.junction_entities.items())
            + list(self.polygon_entities.items())
        )
        # Transfer the resolutions from the photonic device to the optical_simulator
        for name in self.entities.keys():
            if name in self.photodevice.resolutions_optical.keys():
                self.resolutions[name] = self.photodevice.resolutions_optical[name]
        #Lumerical MODE API starts here      
        self.mode = self.lumapi.MODE()
        self.mode.save("try"+"" +".lms")

    def create_geometry(self):
        """
        Creates the geometry in Lumerical MODE
        Needs work to convert into polygons and correct parameter inputs
        ##Use example
        vtx = [1,0;2,2;4,2;4,1;3,1]*1e-6;  # microns
        addpoly;
        set("name","random_polygon");
        set("vertices",vtx);
        set("z span",2e-6);
        ##2D poly
        vtx = [1,0;2,2;4,2;4,1;3,1]*1e-6;  # microns
        add2dpoly;
        set("name","2D_polygon");
        set("surface normal",3); #  1 = x (normal), 2 = y (normal), 3 = z (normal)
        set("vertices",vtx);
        set("z",2e-6);
        """
        # create the primitives (change into polygons)
        for key in self.polygon_entities.keys():
        #     if "metal" in key:
                #     continue
            self.mode.addpoly()
            self.mode.set("name", key)
            self.mode.select(key)
            # Extract the coordinates from the entitity
            x, y = self.mode.polygon_entities[key].exterior.coords.xy
            # Combine the coordinates into a single array
            coords = np.column_stack((x, y))* 1e-6 #in microns
            # Set the vertices
            self.mode.set("vertices", coords)
        
        # for server in [self.mode]:

        #     # Adjust the positions
        #     server.select("geometry")

        #     for key in entities.keys():
        #         print(key)
        #         if "metal" in key:
        #             server.setnamed(key, "x", x_offset)
        #             server.setnamed(key, "y min", y_offset)
        #             server.setnamed(key, "x span", geometry_rect[key]["width"])
        #             server.setnamed(key, "y max", geometry_rect[key]["height"] + y_offset)
        #             server.select(key)
        #             y_offset += geometry_rect[key]["height"]
        #             # lumapi.evalScript(fdtd, 'select("YourGeometryName");')

        #             # Disable the selected geometry
        #             lumapi.evalScript(mode, 'set("enabled", false);')
        #             continue
                
    def create_materials(self):
        """
        Create the materials in Lumerical MODE
        
        """
        
        """
        ###Metals
        
        ###Insulator
        if mode.materialexists("BCB_m"):
            mode.deletematerial("BCB_m")

        lum_BCB = mode.addmaterial("(n,k) Material")
        mode.setmaterial(lum_BCB, "name", "BCB_m")

        mode.setmaterial("BCB_m", "Refractive Index", 1.36)
        mode.setmaterial("BCB_m", "Imaginary Refractive Index", 0)

        if mode.materialexists("Air_m"):
            mode.deletematerial("Air_m")

        lum_Air = mode.addmaterial("(n,k) Material")
        mode.setmaterial(lum_Air, "name", "Air_m")

        mode.setmaterial("Air_m", "Refractive Index", 1)
        mode.setmaterial("Air_m", "Imaginary Refractive Index", 0)

        # if mode.materialexists('Si3N4_m'):
        #     mode.deletematerial('Si3N4_m')

        # lum_Si3N4=mode.addmaterial('(n,k) Material')
        # mode.setmaterial(lum_Si3N4, 'name', 'Si3N4_m')

        # mode.setmaterial('Si3N4_m', 'Refractive Index', 2)
        # mode.setmaterial('Si3N4_m', 'Imaginary Refractive Index', 0)

        if mode.materialexists("SiO2_m"):
            mode.deletematerial("SiO2_m")

        lum_SiO2 = mode.addmaterial("(n,k) Material")
        mode.setmaterial(lum_SiO2, "name", "SiO2_m")

        n0 = 1.44
        nimag = 0

        print("n0:", n0, "nimag:", nimag)
        mode.setmaterial("SiO2_m", "Refractive Index", n0)
        mode.setmaterial("SiO2_m", "Imaginary Refractive Index", nimag)
        def add_sc_mat_mode(mat_data,mode):
            mode_mats = {}
            for matname in mat_data.keys():
                lum_matname=matname+"_m"
                if mode.materialexists(lum_matname):
                    mode.deletematerial(lum_matname)

                mode_mats[matname]=mode.addmaterial("(n,k) Material")
                mode.setmaterial(mode_mats[matname],"name",lum_matname)

                model=combined_materialprop[matname]["class_ins"]
                n0=0
                nimag=0

                if  ("n_InGaAsP" in str(mat_data[matname]['class_ins'])):
                    n0 = np.sqrt(model.get_eps_s()) + model.get_dn_plasma() + model.get_dn_BF()
                    alpha = model.get_dalpha_BF() + model.get_dalpha_plasma()
                    nimag = (
                        alpha
                        / 2
                        / (2 * np.pi / (WAVELENGTH * model.reg.nanometer).to(model.reg.centimeter))
                    )
                # except AttributeError:
                    # print(matname+" Ref. Index calculation failed due to doping type (plasma for n, iv for p)")

                elif ("p_InGaAsP" in str(mat_data[matname]['class_ins'])):
                    # print(np.sqrt(model.get_eps_s()) , model.get_dn_iv() , model.get_dn_BF())
                    n0 = np.sqrt(model.get_eps_s()) + model.get_dn_iv() + model.get_dn_BF()
                    alpha = model.get_dalpha_BF() + model.get_dalpha_iv()
                    nimag = (
                        alpha
                        / 2
                        / (2 * np.pi / (WAVELENGTH * model.reg.nanometer).to(model.reg.centimeter))
                    )

                else:
                    print('something wrong')


                # print("n0:", n0, "nimag:", nimag)
                # print(matname,'/',n0.magnitude,'/''/',nimag.magnitude)
                mode.setmaterial(lum_matname, "Refractive Index", n0.magnitude)
                mode.setmaterial(lum_matname, "Imaginary Refractive Index", nimag.magnitude)
        """
        ###Semiconductor
        
        #Single function to add materials
        def add_sc_mat_mode(photo_polygons, mat_data, mode):
            mode_mats = {}
            for polygon in photo_polygons:
                if isinstance(polygon, SemiconductorPolygon):
                    matname = polygon.name
                    lum_matname = matname + "_m"
                    if mode.materialexists(lum_matname):
                        mode.deletematerial(lum_matname)

                    mode_mats[matname] = mode.addmaterial("(n,k) Material")
                    mode.setmaterial(mode_mats[matname], "name", lum_matname)

                    model = combined_materialprop[matname]["class_ins"]
                    n0 = 0
                    nimag = 0

                    if "n_InGaAsP" in str(mat_data[matname]['class_ins']):
                        n0 = np.sqrt(model.get_eps_s()) + model.get_dn_plasma() + model.get_dn_BF()
                        alpha = model.get_dalpha_BF() + model.get_dalpha_plasma()
                        nimag = alpha / 2 / (2 * np.pi / (WAVELENGTH * model.reg.nanometer).to(model.reg.centimeter))

                    elif "p_InGaAsP" in str(mat_data[matname]['class_ins']):
                        n0 = np.sqrt(model.get_eps_s()) + model.get_dn_iv() + model.get_dn_BF()
                        alpha = model.get_dalpha_BF() + model.get_dalpha_iv()
                        nimag = alpha / 2 / (2 * np.pi / (WAVELENGTH * model.reg.nanometer).to(model.reg.centimeter))

                    else:
                        print('something wrong')

                    mode.setmaterial(lum_matname, "Refractive Index", n0.magnitude)
                    mode.setmaterial(lum_matname, "Imaginary Refractive Index", nimag.magnitude)
        # Cycle through non-semiconductor polygons and add their materials
        def add_mat_mode(photo_polygons, mode):
            for polygon in photo_polygons:
                if not isinstance(polygon, SemiconductorPolygon):
                    matname = polygon.name
                    lum_matname = matname + "_m"
                    if mode.materialexists(lum_matname):
                        mode.deletematerial(lum_matname)

                    mode_mat = mode.addmaterial("(n,k) Material")
                    mode.setmaterial(mode_mat, "name", lum_matname)

                    # Set material properties (example values)
                    n0 = 1.5  # Example refractive index
                    nimag = 0  # Example imaginary refractive index
                    mode.setmaterial(lum_matname, "Refractive Index", n0)
                    mode.setmaterial(lum_matname, "Imaginary Refractive Index", nimag)
                
        # add_sc_mat_mode(self.optical_photopolygons, combined_materialprop, mode)
        add_mat_mode(self.optical_photopolygons,mode)
        
        #SET COLOR TO MATERIALS
        nonSCmatCount=3
        # Number of colors you want
        N = len(combined_materialprop.keys())

        # Generate N random RGB colors
        colors = np.random.randint(0, 256, size=(N, 3))

        # Ensure contrasting colors
        for i in range(1, N):
            while np.linalg.norm(colors[i] - colors[i-1]) < 50:  # Adjust the threshold as needed
                colors[i] = np.random.randint(0, 256, size=3)

        # Convert the colors to a list
        cl = [tuple(color) for color in colors]
        
        for i, matname in enumerate(combined_materialprop.keys()):
            lum_matname=matname+"_m"
            mode.setmaterial(lum_matname,"color",np.asarray([[cl[i][0] / 255], [cl[i][1] / 255], [cl[i][1] / 255], [1]]))
            
            
        ###SET MATERIALS TO GEOMETRY
        
        #Go through each non-metal materials and set the pre-defined materials to each layer
        for layer in combined_materialprop.keys():
            lum_matname=layer+"_m"
            try:
                mode.setnamed(layer,"material",lum_matname)
                print(lum_matname)
            except lumapi.LumApiError: #There might be more material defined then geometry, except error and continue in the loop
                continue

    def create_fde(self):
        self.mode.addfde()
        self.mode.select("FDE")

        self.mode.set("solver type", "2D Z normal")
        self.mode.set("x", 0)
        self.mode.set("x span", w_bot+3e-6)
        self.mode.set("y max", self.mode.getnamed("metal_p","y max")+3e-7)
        self.mode.set("y min", self.mode.getnamed("metal_n","y min")-3e-7)
        # self.mode.set("z span", (H_SiO2 + h_BCB + h_n2 + h_wg1 + h_wg2 + h_wg3 + h_p2 + h_p1))
        # self.mode.set("z", self.mode.getnamed("WG2", "z"))
        # print(self.mode.get())

        # mesh settings
        self.mode.set("define x mesh by", "maximum mesh step")
        self.mode.set("define y mesh by", "maximum mesh step")
        self.mode.set("dx", w_base*0.01)
        self.mode.set("dy", 10e-9)

        # background
        self.mode.select("FDE")
        self.mode.set("search", "near n")
        self.mode.set("use max index", True)
        self.mode.set("number of trial modes",10)
        self.mode.set("index", 1.5) #background index
    
    def make_mesh(self):
        print("Meshing")
    
    def compute_modes(
        self,
        wavelength: float = 1.55,
        voltage_idx: int = 0,
        num_modes: int = 4,
        order: int = 1,
        return_modes: bool = False,
    ) -> Modes:

        mode.findmodes()

        ###seperate TE TM modes
        mode1TEfrac=mode.getresult("FDE::data::mode" + str(1), "TE polarization fraction")
        mode2TEfrac=mode.getresult("FDE::data::mode" + str(2), "TE polarization fraction")

        #in case the correct mode indexes different use the below line instead of if statements
        #modes_idx = [1, 0] #mode number - 1 written[TE, TM]
        if mode2TEfrac>mode1TEfrac:
            modes_idx = [1, 0]
        else:
            modes_idx = [0, 1]
        print(modes_idx)
        N_modes = len(modes_idx)
        Efield_modes = [mode.getresult("FDE::data::mode" + str(i + 1), "E") for i in modes_idx]
        Hfield_modes = [mode.getresult("FDE::data::mode" + str(i + 1), "H") for i in modes_idx]

        self.modes = modes.sorted(lambda mode: mode.n_eff.real)[::-1]

        if return_modes:
            return self.modes

    def plot_mode(
        self,
        mode: Mode,
        figsize: tuple[float, float] = (10,3),
        color_polygons: str = "black"
    ):
        
        
        k = 0
        Ex = Efield_modes[k]["E"][:, :, 0, 0, 0].transpose()
        Ey = Efield_modes[k]["E"][:, :, 0, 0, 1].transpose()
        Ez = Efield_modes[k]["E"][:, :, 0, 0, 2].transpose()
        
        xx, yy = np.meshgrid(Efield_modes[k]["x"][:, 0], Efield_modes[k]["y"][:, 0])
        print(xx.shape, yy.shape)
        
        fig = plt.figure(figsize=(6, 6))
        gs = GridSpec(2, 1)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[1, 0])
        
        divider1 = make_axes_locatable(ax1)
        cax1 = divider1.append_axes("right", size="5%", pad=0.05)
        # im1 = ax1.imshow(np.abs(Ex)**2+np.abs(Ey)**2+np.abs(Ez)**2, cmap='jet', extent=[np.min(Efield_modes[k]['x']),
        #                                                                                 np.max(Efield_modes[k]['x']),
        #                                                                                 np.min(Efield_modes[k]['y']),
        #                                                                                 np.max(Efield_modes[k]['y'])], origin='lower')
        im1 = ax1.imshow(
            np.abs(Ex) ** 2 + np.abs(Ey) ** 2 + np.abs(Ez) ** 2,
            cmap="jet",
            extent=[
                np.min(Efield_modes[k]["x"][:, 0]),
                np.max(Efield_modes[k]["x"][:, 0]),
                np.min(Efield_modes[k]["y"][:, 0]),
                np.max(Efield_modes[k]["y"][:, 0]),
            ],
            origin="lower",
        )
        
        fig.colorbar(im1, cax=cax1, orientation="vertical")
        
        Ex = Efield_modes[k + 1]["E"][:, :, 0, 0, 0].transpose()
        Ey = Efield_modes[k + 1]["E"][:, :, 0, 0, 1].transpose()
        Ez = Efield_modes[k + 1]["E"][:, :, 0, 0, 2].transpose()
        
        divider2 = make_axes_locatable(ax2)
        cax2 = divider2.append_axes("right", size="5%", pad=0.05)
        
        # tmp[np.where(tmp<0.1)]=0
        im2 = ax2.imshow(
            np.abs(Ex) ** 2 + np.abs(Ey) ** 2 + np.abs(Ez) ** 2,
            cmap="jet",
            extent=[
                np.min(Efield_modes[k + 1]["x"]),
                np.max(Efield_modes[k + 1]["x"]),
                np.min(Efield_modes[k + 1]["y"]),
                np.max(Efield_modes[k + 1]["y"]),
            ],
            origin="lower",
            vmin=0,
        )
        
        fig.colorbar(im2, cax=cax2, orientation="vertical")
        
        
        # ax1.set_xlim(-2.5e-6, 2.5e-6)
        # ax1.set_ylim(-4e-6, 150e-9/2)
        ax1.set_ylabel("y (m)")
        ax1.set_xlabel("x (m)")
        ax1.set_title(r"$|E|^2$ | TE")
        
        ax2.set_xlim(np.min(Efield_modes[k + 1]["x"]), np.max(Efield_modes[k + 1]["x"]))
        ax2.set_ylim(np.min(Efield_modes[k + 1]["y"]), np.max(Efield_modes[k + 1]["y"]))
        ax2.set_ylabel("y (m)")
        ax2.set_xlabel("x (m)")
        ax2.set_title(r"$|E|^2$ | TM")
        
        # fig.savefig("modes.png", bbox_inches="tight", dpi=400)
        fig.tight_layout()
    
    def plot_polygons(
        self,
        color_polygon="black",
        color_line="green",
        color_junctions="blue",
        fig=None,
        ax=None,
    ):
        "plots all the polygons and boundaries"
        if fig is None and ax is None:
            fig = plt.figure()
            ax = fig.add_subplot(111)

        for name, poly in self.entities.items():
            if isinstance(poly, Polygon):
                ax.plot(
                    *poly.exterior.xy,
                    color=color_polygon if "junction" not in name else color_junctions,
                )
            elif isinstance(poly, Line):
                ax.plot(*poly.xy, color=color_line)
    


# %%
Mode=OpticalSimulatorMODE(device=wg_unetched.device)
Mode.create_geometry()

# %%
print(Mode.polygon_entities['layer1'].exterior,'/n',Mode.polygon_entities['layer1'].exterior.coords.xy)


# %%
Mode.mode.select("layer1")

# %%
# Extract the coordinates
x, y = Mode.polygon_entities['layer1'].exterior.coords.xy

# Combine the coordinates into a single array
coords = np.column_stack((x, y))

# Scale the coordinates by 1e-6
coords_scaled = coords * 1e-6


# %%
np.shape(vtx)

# %%
type(vtx[0][0])

# %%
Mode.mode.set("vertices", coords)


