from __future__ import annotations

import numpy as np
from scipy.interpolate import interp1d
import uuid
from dataclasses import dataclass, field
from shapely.geometry import Polygon, MultiPolygon

from imodulator.ElectroOpticalModel import (
    ElectroOpticalModel
)

class SemiconductorPolygon:
    """
    Base class for a polygon with semiconductor properties. 

    What distinguishes this class from :class:`InsulatorPolygon <imodulator.PhotonicPolygon.Insulator.Polygon>` is that it will not only allow additional settings to be passed on to the charge transport simulator, but it also stores the results of the charge transport simulations in the object itself. Such properties take the form:

    Attributes:
        N (list[Callable]): The electron concentration in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        P (list[Callable]): The hole concentration in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        Ec (list[Callable]): The conduction band energy in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        Ev (list[Callable]): The valence band energy in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        Efp (list[Callable]): The quasi-Fermi level for electrons in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        Efn (list[Callable]): The quasi-Fermi level for holes in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        mup (list[Callable]): The mobility of holes in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        mun (list[Callable]): The mobility of electrons in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        Efield (list[Callable]): The electric field in the semiconductor. Each element of the list is a callable with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice.
        
        has_charge_transport_data (bool): A flag to indicate whether the object has charge transport data.

    """

    def __init__(
        self,
        polygon: Polygon | MultiPolygon,
        name: str | None = None,
        optical_material: str | complex = 1 + 0j,
        rf_eps: float | complex | int | np.ndarray = 1,
        electro_optic_module: None | ElectroOpticalModel = None,
        electro_optic_module_kwargs: dict = {},
        calculate_current: bool = False,
        d_buffer_current: bool = False,
        eo_mesh_settings: dict[str, float] = {
            "resolution": 0.1,
            "SizeMax": 0.1,
            "distance": 0.1,
            "resolution_junction": 0,
            "distance_junction": 0,
        },
        rf_mesh_settings: dict[str, float] = {
            "resolution": 0.1,
            "SizeMax": 0.1,
            "distance": 0.1,
            "resolution_junction": 0,
            "distance_junction": 0,
        },
        optical_mesh_settings: dict[str, float] = {
            "resolution": 0.1,
            "SizeMax": 0.1,
            "distance": 0.1,
            "resolution_junction": 0,
            "distance_junction": 0,
        },
        charge_transport_simulator_kwargs: dict | None = None,
    ):
       
        """
        Initialize a SemiconductorPolygon object with the specified parameters. All the input spatial dimensions are assumed to be in micrometers, and the frequencies are in GHz.

        Args:
            polygon: a polygon
            
            name: the name of the polygon. If it is not given a unique id will be generated automatically.
            
            optical_material: the optical material properties of the polygon. This will be deprecated in the future.
            
            rf_eps: the relative permittivity of the polygon. Material information for RF simulations if charge transport simulation. Internally, it will be converted to a callable function of the type f(omega). If you input a float, then it is constant for all frequencies, and if you give it a ``np.array`` of shape `(2,N)` then it will interpolate to give a callable of the same signature.
            
            electro_optic_module: the electro-optic module associated with the polygon. This is the model that will later be used by :class:`ElectroOpticalSimulator <imodulator.ElectroOpticalSimulator.ElectroOpticalSimulator>` to calculate the electro-optic effect.
            
            electro_optic_module_kwargs: the keyword arguments for the electro-optic module.

            calculate_current: a flag to indicate whether to calculate current.
            
            d_buffer_current: the buffer distance for current calculation. The current is calculated with a line integral around the object. This parameter sets the distance from the object where the line integral is calculated.
            
            eo_mesh_settings: the mesh settings for electro-optic simulations. It is a dictionary with the following keys:

                * **SizeMax** (float): the maximum size of the mesh at a ``distance`` from the object;
                * **resolution** (float): the maximum size of the mesh *inside* the polygon;
                * **distance** (float): the distance from the object where the mesh size is ``SizeMax``;
                * **distance_junction** (float): If there is a boundary of the type Semiconductor-Semiconductor, Semiconductor-Insulator a new polygon can be automatically inserted that captures the junction. This new polygon is inserted only in the direction of the semiconductor. ``distance_junction`` controls how deep into the semiconductor it goes;
                * **resolution_junction** (float): the maximum size of the mesh *inside* the junction;

                .. warning::
                    The algorithm to search for junctions is not active at the moment. It is a feature that will be implemented in the future.

            rf_mesh_settings: the mesh settings for RF simulations. It is a dictionary with the same keys as ``eo_mesh_settings``.

            optical_mesh_settings: the mesh settings for optical simulations. It is a dictionary with the same keys as ``eo_mesh_settings``.

            charge_transport_simulator_kwargs: additional keyword arguments for the charge transport simulator.
        """
        self.polygon = polygon
        self.name = str(uuid.uuid4()) if name is None else name
        self.charge_transport_simulator_kwargs = charge_transport_simulator_kwargs

        if isinstance(rf_eps, float | complex | int):
            self.rf_eps = lambda omega: rf_eps
        elif isinstance(rf_eps, np.ndarray):
            self.rf_eps = lambda omega: interp1d(2*np.pi*rf_eps[0], rf_eps[1])(omega)


        self.optical_material = optical_material
        self.electro_optic_module = electro_optic_module
        self.electro_optic_module_kwargs = electro_optic_module_kwargs
        self.calculate_current = calculate_current
        self.d_buffer_current = d_buffer_current

        self.eo_mesh_settings = eo_mesh_settings
        self.rf_mesh_settings = rf_mesh_settings
        self.optical_mesh_settings = optical_mesh_settings

        default_mesh_settings = {
            "resolution": 100,
            "SizeMax": 100,
            "distance": 0.0,
            "resolution_junction": 100,
            "distance_junction": 0,
        }

        for key, value in default_mesh_settings.items():
            if key not in self.eo_mesh_settings:
                self.eo_mesh_settings[key] = value

            if key not in self.rf_mesh_settings:
                self.rf_mesh_settings[key] = value

            if key not in self.optical_mesh_settings:
                self.optical_mesh_settings[key] = value


        #We will store here the results of the charge transport simulations
        # These must be lists of callables (one for each voltage) with the signature f(x,y) -> Pint.Quantity with the register of PhotonicDevice
        self.has_charge_transport_data = False
        self.mup = [lambda x,y: None]
        self.mun = [lambda x,y: None]
        self.Ec = [lambda x,y: None]
        self.Ev = [lambda x,y: None]
        self.Efp = [lambda x,y: None]
        self.Efn = [lambda x,y: None]
        self.P = [lambda x,y: None]
        self.N = [lambda x,y: None]
        self.Efield = [lambda x,y: None]


@dataclass
class MetalPolygon:
    polygon: Union[Polygon, MultiPolygon]